import sys
sys.path.append('./fnn')
import numpy as np
import pandas as pd
import scipy.io as scio
from myModel import LSTMEmbedding, MLPEmbedding, ETDEmbedding, AMIEmbedding, TICAEmbedding
from fnn.regularizers import FNN
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import axes3d
import tensorflow as tf
import tensorflow.keras as keras
import tensorflow.keras.layers as layers
from tensorflow.keras.models import load_model
import pickle

# plt.rcParams['lines.linewidth'] = .02
# plt.rcParams['axes.prop_cycle'] = plt.cycler(color="k")

dd1 = scio.loadmat('./mydatasets/allSignal_rightTime.mat')
x1 = dd1['xdata']
y1 = dd1['yd'][0,:]

random_dex = np.random.permutation(x1.shape[0])
y1 = y1/300

xdata = x1[random_dex, :]
ydata = y1[random_dex]

# LSTM
my_model = []
for idx in range(6):
    lstm_model = LSTMEmbedding(64,
                         time_window=128,
                         latent_regularizer=FNN(10),
                         random_state=0
                         )
    left = idx*128*3
    right = left+128*3
    temp = xdata[:,left:right]
    temp1 = temp.reshape((-1,128))  #确认reshape之后每128是不是计划中的
    rd_idx = np.random.permutation(temp1.shape[0])
    tdata = lstm_model.fit_transform(temp1[rd_idx,:])

    my_model.append(lstm_model)

output = open('./model/model.pkl','wb')
pickle.dump(my_model,output)
output.close()

# train_idx = int(x1.shape[0]*0.7)
# # xtrain = x_data[:train_idx,1:]
# # ytrain = ydata[:train_idx]
# # xtest = x_data[train_idx:,1:]
# # ytest = ydata[train_idx:]
#
# input1 = tf.keras.Input(shape=(64), name='input1')
# h1 = layers.Conv2D(512, kernel_size=(1, 2), strides=(1, 1), activation='relu', padding='same')(input1)
# f1 = layers.Flatten()(h1)
# h2 = layers.Dense(1024, activation='relu')(f1)
# h3 = layers.Dense(1024, activation='relu')(h2)
# output = layers.Dense(1)(h3)
#
# model = keras.models.Model(inputs=input1, outputs=output)
#
# model.compile(optimizer=keras.optimizers.RMSprop(1e-3), loss='mean_absolute_percentage_error',
#               metrics=['mean_absolute_error'])
# # model.fit(xtrain, ytrain, batch_size=500, epochs=200, validation_split=0.2)
#
#


